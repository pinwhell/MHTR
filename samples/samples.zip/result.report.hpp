#pragma once

#include <cstdint>

namespace Dummy {
    constexpr auto BarPattern = "42 00 ? B9";
    constexpr uint64_t BarPatternResult = 0x1A94;
    constexpr uint64_t Baz = 0x2640;
    constexpr uint64_t Foo = 0x15B0;
    constexpr uint64_t Bar = 0x42;
}